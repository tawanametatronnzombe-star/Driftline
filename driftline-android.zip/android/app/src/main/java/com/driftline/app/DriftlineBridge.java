package com.driftline.app;

import android.Manifest;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

/**
 * JavaScript bridge exposed to the web app as window.DriftlineNative.
 * Contract (kept in sync with index.html):
 *   isNative(), version(), notificationsAllowed(), requestNotifications(),
 *   notify(title, body, chatId, tag), saveFile(name, mime, base64), share(title, text, url),
 *   vibrate(ms), startListening(lang), stopListening()
 * Speech results are pushed back as window.__dlStt('{"type":"partial|final|error","text":"..."}').
 */
public class DriftlineBridge {
    static final String CHANNEL_ID = "driftline_messages";

    private final MainActivity act;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private boolean wantListening = false;

    DriftlineBridge(MainActivity activity) {
        this.act = activity;
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Messages and calls",
                        NotificationManager.IMPORTANCE_HIGH);
                ch.setDescription("New messages, calls and connections");
                nm.createNotificationChannel(ch);
            }
        }
    }

    @JavascriptInterface
    public boolean isNative() { return true; }

    @JavascriptInterface
    public String version() {
        try {
            return act.getPackageManager().getPackageInfo(act.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "3.0.0";
        }
    }

    @JavascriptInterface
    public boolean notificationsAllowed() {
        if (Build.VERSION.SDK_INT >= 33) {
            return act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }
        NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm == null || nm.areNotificationsEnabled();
    }

    @JavascriptInterface
    public void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !notificationsAllowed()) {
            act.runOnUiThread(new Runnable() {
                @Override public void run() {
                    act.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, MainActivity.REQ_NOTIF);
                }
            });
        }
    }

    @JavascriptInterface
    public void notify(String title, String body, String chatId, String tag) {
        if (!notificationsAllowed()) return;
        try {
            Intent i = new Intent(act, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            if (chatId != null && chatId.length() > 0) i.putExtra(MainActivity.EXTRA_CHAT_ID, chatId);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            int id = (tag == null ? "driftline" : tag).hashCode();
            PendingIntent pi = PendingIntent.getActivity(act, id, i, flags);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(act, CHANNEL_ID) : new Notification.Builder(act);
            b.setSmallIcon(R.drawable.ic_stat_notify).setContentTitle(title).setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setAutoCancel(true).setContentIntent(pi);
            if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
            NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(id, b.build());
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public boolean saveFile(String name, String mime, String base64) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            String safe = (name == null || name.length() == 0 ? "driftline-file" : name).replaceAll("[\\\\/:*?\"<>|]", "_");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                v.put(MediaStore.Downloads.MIME_TYPE, mime == null || mime.length() == 0 ? "application/octet-stream" : mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Driftline");
                Uri uri = act.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return false;
                OutputStream os = act.getContentResolver().openOutputStream(uri);
                os.write(data); os.close();
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Driftline");
                if (!dir.exists()) dir.mkdirs();
                FileOutputStream os = new FileOutputStream(new File(dir, safe));
                os.write(data); os.close();
            }
            toast("Saved to Downloads/Driftline");
            return true;
        } catch (Exception e) {
            toast("Could not save the file");
            return false;
        }
    }

    @JavascriptInterface
    public void share(String title, String text, String url) {
        try {
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Driftline" : title);
            s.putExtra(Intent.EXTRA_TEXT, (text == null ? "" : text) + (url == null || url.length() == 0 ? "" : "\n" + url));
            Intent c = Intent.createChooser(s, "Share");
            c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(c);
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void vibrate(int ms) {
        try {
            Vibrator v = (Vibrator) act.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(Math.max(1, Math.min(ms, 500)), VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(Math.max(1, Math.min(ms, 500)));
        } catch (Exception ignored) { }
    }

    // ---------------- speech recognition for Pip voice calls ----------------

    @JavascriptInterface
    public void startListening(final String lang) {
        wantListening = true;
        main.post(new Runnable() {
            @Override public void run() {
                if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    act.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MainActivity.REQ_STT);
                    return;
                }
                beginListening(lang);
            }
        });
    }

    private void beginListening(String lang) {
        if (!SpeechRecognizer.isRecognitionAvailable(act)) { push("error", "unavailable"); return; }
        destroyRecognizer();
        recognizer = SpeechRecognizer.createSpeechRecognizer(act);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float r) { }
            @Override public void onBufferReceived(byte[] b) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onEvent(int t, Bundle p) { }
            @Override public void onError(int e) {
                if (!wantListening) return;
                if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) push("final", "");
                else if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) push("error", "not-allowed");
                else push("error", "network");
            }
            @Override public void onPartialResults(Bundle b) {
                ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (l != null && !l.isEmpty()) push("partial", l.get(0));
            }
            @Override public void onResults(Bundle b) {
                ArrayList<String> l = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                push("final", l != null && !l.isEmpty() ? l.get(0) : "");
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang == null || lang.length() == 0 ? "en-US" : lang);
        recognizer.startListening(i);
    }

    @JavascriptInterface
    public void stopListening() {
        wantListening = false;
        main.post(new Runnable() { @Override public void run() { destroyRecognizer(); } });
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void push(String type, String text) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", type);
            o.put("text", text == null ? "" : text);
            act.runJs("window.__dlStt&&window.__dlStt(" + JSONObject.quote(o.toString()) + ");");
        } catch (Exception ignored) { }
    }

    private void toast(final String t) {
        act.runOnUiThread(new Runnable() { @Override public void run() { Toast.makeText(act, t, Toast.LENGTH_SHORT).show(); } });
    }

    void onPermissionResult(int requestCode, int[] grants) {
        boolean ok = grants != null && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == MainActivity.REQ_STT) {
            if (ok && wantListening) beginListening("en-US");
            else if (!ok) push("error", "not-allowed");
        }
    }

    void destroy() {
        wantListening = false;
        destroyRecognizer();
    }
}
