package com.driftline.app;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Full-screen WebView wrapper around the Driftline web app (online only).
 */
public class MainActivity extends Activity {

    /** Default site. Can be overridden through the string resource "site_url". */
    static final String DEFAULT_URL = "https://tawanametatronnzombe-star.github.io/Driftline/";

    static final String EXTRA_CHAT_ID = "com.driftline.app.CHAT_ID";

    static final int REQ_FILE = 1001;
    static final int REQ_WEB_PERMS = 1002;
    static final int REQ_NOTIF = 1003;
    static final int REQ_STT = 1004;
    static final int REQ_STORAGE = 1005;

    private static final int BG = 0xFF0D1016;

    private FrameLayout root;
    private WebView webView;
    private LinearLayout offlineView;
    private FrameLayout fullscreenContainer;

    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebRequest;

    private DriftlineBridge bridge;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    private String siteUrl;
    private String allowedHost;
    private String lastUrl;
    private boolean loadFailed = false;
    private boolean pageLoaded = false;
    private String pendingChatId = null;

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        siteUrl = readSiteUrl();
        String host = Uri.parse(siteUrl).getHost();
        allowedHost = host == null ? "" : host;

        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        buildUi();
        setupWebView();

        bridge = new DriftlineBridge(this);
        webView.addJavascriptInterface(bridge, "DriftlineNative");

        registerNetworkCallback();

        String start = handleIntent(getIntent());
        loadUrlOrOffline(start);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String url = handleIntent(intent);
        if (url != null) {
            loadUrlOrOffline(url);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onPause() {
        // Deliberately NOT calling webView.onPause(): the page should keep running
        // (calls, sockets, in-app notifications) while the app is in the background.
        try {
            CookieManager.getInstance().flush();
        } catch (Exception e) {
            // ignore
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (connectivityManager != null && networkCallback != null) {
            try {
                connectivityManager.unregisterNetworkCallback(networkCallback);
            } catch (Exception e) {
                // ignore
            }
            networkCallback = null;
        }
        if (bridge != null) {
            bridge.destroy();
        }
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
        if (webView != null) {
            webView.stopLoading();
            if (webView.getParent() instanceof ViewGroup) {
                ((ViewGroup) webView.getParent()).removeView(webView);
            }
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (offlineView.getVisibility() == View.VISIBLE) {
            moveTaskToBack(true);
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            moveTaskToBack(true);
        }
    }

    // ------------------------------------------------------------------
    // UI construction
    // ------------------------------------------------------------------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        webView = new WebView(this);
        webView.setBackgroundColor(BG);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        offlineView = new LinearLayout(this);
        offlineView.setOrientation(LinearLayout.VERTICAL);
        offlineView.setGravity(Gravity.CENTER);
        offlineView.setBackgroundColor(BG);
        offlineView.setPadding(dp(32), dp(32), dp(32), dp(32));
        offlineView.setVisibility(View.GONE);
        // Swallow touches so nothing reaches the hidden WebView.
        offlineView.setClickable(true);

        TextView title = new TextView(this);
        title.setText(R.string.offline_title);
        title.setTextColor(Color.WHITE);
        title.setTextSize(24f);
        title.setGravity(Gravity.CENTER);

        TextView message = new TextView(this);
        message.setText(R.string.offline_message);
        message.setTextColor(0xFFAAB2C0);
        message.setTextSize(16f);
        message.setGravity(Gravity.CENTER);
        message.setPadding(0, dp(12), 0, dp(24));

        Button retry = new Button(this);
        retry.setText(R.string.retry);
        retry.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF4F8CFF);
        bg.setCornerRadius(dp(24));
        retry.setBackground(bg);
        retry.setPadding(dp(32), dp(12), dp(32), dp(12));
        retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                retryLoad();
            }
        });

        offlineView.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        offlineView.addView(message, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        offlineView.addView(retry, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(offlineView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        fullscreenContainer = new FrameLayout(this);
        fullscreenContainer.setBackgroundColor(Color.BLACK);
        fullscreenContainer.setVisibility(View.GONE);
        root.addView(fullscreenContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowContentAccess(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " DriftlineApp/3.0");

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        // Third-party cookies are needed by embedded media players (iframes).
        cm.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new AppWebViewClient());
        webView.setWebChromeClient(new AppChromeClient());
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimetype, long contentLength) {
                handleDownload(url, userAgent, contentDisposition, mimetype);
            }
        });
    }

    // ------------------------------------------------------------------
    // URL / intent handling
    // ------------------------------------------------------------------

    private String readSiteUrl() {
        String r = getString(R.string.site_url);
        if (r == null) {
            return DEFAULT_URL;
        }
        r = r.trim();
        return r.length() == 0 ? DEFAULT_URL : r;
    }

    private boolean isAppUri(Uri uri) {
        if (uri == null) {
            return false;
        }
        String scheme = uri.getScheme();
        String host = uri.getHost();
        return "https".equalsIgnoreCase(scheme) && host != null
                && host.equalsIgnoreCase(allowedHost);
    }

    /**
     * Reads the chat id extra (stores it as pending) and returns the URL to load,
     * or null when the intent asks for no navigation. On first launch the caller
     * falls back to the site URL.
     */
    private String handleIntent(Intent intent) {
        boolean first = (webView != null && lastUrl == null && !pageLoaded && !loadFailed);
        String url = null;
        if (intent != null) {
            Uri data = intent.getData();
            if (Intent.ACTION_VIEW.equals(intent.getAction()) && isAppUri(data)) {
                url = data.toString(); // includes #fragment
            }
            String chatId = intent.getStringExtra(EXTRA_CHAT_ID);
            if (chatId != null && chatId.length() > 0) {
                intent.removeExtra(EXTRA_CHAT_ID);
                pendingChatId = chatId;
                if (pageLoaded && url == null) {
                    flushPendingChat();
                }
            }
        }
        if (url == null && first) {
            url = siteUrl;
        }
        return url;
    }

    private void loadUrlOrOffline(String url) {
        if (url == null || webView == null) {
            return;
        }
        lastUrl = url;
        if (!isOnline()) {
            showOffline();
            return;
        }
        hideOffline();
        loadFailed = false;
        webView.loadUrl(url);
    }

    private void retryLoad() {
        if (!isOnline()) {
            Toast.makeText(this, R.string.still_offline, Toast.LENGTH_SHORT).show();
            return;
        }
        hideOffline();
        loadFailed = false;
        if (webView != null) {
            webView.loadUrl(lastUrl != null ? lastUrl : siteUrl);
        }
    }

    boolean isOnline() {
        if (connectivityManager == null) {
            return true; // cannot tell; let the WebView try
        }
        try {
            Network n = connectivityManager.getActiveNetwork();
            if (n == null) {
                return false;
            }
            NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(n);
            return caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } catch (Exception e) {
            return true;
        }
    }

    private void showOffline() {
        offlineView.setVisibility(View.VISIBLE);
        if (webView != null) {
            webView.setVisibility(View.INVISIBLE);
        }
    }

    private void hideOffline() {
        offlineView.setVisibility(View.GONE);
        if (webView != null) {
            webView.setVisibility(View.VISIBLE);
        }
    }

    private void registerNetworkCallback() {
        if (connectivityManager == null) {
            return;
        }
        try {
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (offlineView != null && offlineView.getVisibility() == View.VISIBLE) {
                                retryLoad();
                            }
                        }
                    });
                }
            };
            connectivityManager.registerDefaultNetworkCallback(networkCallback);
        } catch (Exception e) {
            networkCallback = null;
        }
    }

    private void openExternal(Uri uri) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(i);
        } catch (Exception e) {
            // No app can handle it; ignore.
        }
    }

    // ------------------------------------------------------------------
    // JS helpers (used by the bridge too)
    // ------------------------------------------------------------------

    void runJs(final String js) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (webView != null) {
                    webView.evaluateJavascript(js, null);
                }
            }
        });
    }

    private void flushPendingChat() {
        final String id = pendingChatId;
        if (id == null) {
            return;
        }
        pendingChatId = null;
        String q = JSONObject.quote(id);
        String js = "(function(id){var n=0;(function t(){"
                + "if(typeof window.__dlOpenChat==='function'){window.__dlOpenChat(id);}"
                + "else if(n++<20){setTimeout(t,500);}"
                + "})();})(" + q + ");";
        runJs(js);
    }

    // ------------------------------------------------------------------
    // Downloads
    // ------------------------------------------------------------------

    private void handleDownload(String url, String userAgent, String contentDisposition,
                                String mimetype) {
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) {
            return; // blob:/data: downloads go through DriftlineNative.saveFile
        }
        try {
            String filename = URLUtil.guessFileName(url, contentDisposition, mimetype);
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            if (mimetype != null && mimetype.length() > 0) {
                req.setMimeType(mimetype);
            }
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) {
                req.addRequestHeader("Cookie", cookie);
            }
            if (userAgent != null) {
                req.addRequestHeader("User-Agent", userAgent);
            }
            req.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(req);
            Toast.makeText(this, R.string.download_started, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            // Fall back to the browser (e.g. missing storage permission on old Android).
            openExternal(Uri.parse(url));
        }
    }

    // ------------------------------------------------------------------
    // Fullscreen video
    // ------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    private void showCustomView(View view, WebChromeClient.CustomViewCallback callback) {
        if (customView != null) {
            callback.onCustomViewHidden();
            return;
        }
        customView = view;
        customViewCallback = callback;
        fullscreenContainer.addView(view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        fullscreenContainer.setVisibility(View.VISIBLE);
        if (webView != null) {
            webView.setVisibility(View.INVISIBLE);
        }
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @SuppressWarnings("deprecation")
    private void hideCustomView() {
        if (customView == null) {
            return;
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        fullscreenContainer.removeView(customView);
        fullscreenContainer.setVisibility(View.GONE);
        customView = null;
        if (webView != null && offlineView.getVisibility() != View.VISIBLE) {
            webView.setVisibility(View.VISIBLE);
        }
        if (customViewCallback != null) {
            customViewCallback.onCustomViewHidden();
            customViewCallback = null;
        }
    }

    // ------------------------------------------------------------------
    // Permissions / activity results
    // ------------------------------------------------------------------

    private boolean hasPermission(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void handleWebPermission(PermissionRequest request) {
        if (!isAppUri(request.getOrigin())) {
            request.deny();
            return;
        }
        List<String> needed = new ArrayList<String>();
        for (String res : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)
                    && !hasPermission(Manifest.permission.RECORD_AUDIO)) {
                needed.add(Manifest.permission.RECORD_AUDIO);
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)
                    && !hasPermission(Manifest.permission.CAMERA)) {
                needed.add(Manifest.permission.CAMERA);
            }
        }
        if (needed.isEmpty()) {
            grantAllowed(request);
            return;
        }
        if (pendingWebRequest != null) {
            pendingWebRequest.deny();
        }
        pendingWebRequest = request;
        requestPermissions(needed.toArray(new String[needed.size()]), REQ_WEB_PERMS);
    }

    /** Grants the audio/video resources whose Android permission is now held. */
    private void grantAllowed(PermissionRequest request) {
        List<String> ok = new ArrayList<String>();
        for (String res : request.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)
                    && hasPermission(Manifest.permission.RECORD_AUDIO)) {
                ok.add(res);
            } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res)
                    && hasPermission(Manifest.permission.CAMERA)) {
                ok.add(res);
            }
        }
        if (ok.isEmpty()) {
            request.deny();
        } else {
            request.grant(ok.toArray(new String[ok.size()]));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_WEB_PERMS) {
            PermissionRequest r = pendingWebRequest;
            pendingWebRequest = null;
            if (r != null) {
                grantAllowed(r);
            }
        } else if (bridge != null) {
            bridge.onPermissionResult(requestCode, grantResults);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            ValueCallback<Uri[]> cb = fileCallback;
            fileCallback = null;
            if (cb != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK) {
                    results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                }
                cb.onReceiveValue(results); // null when cancelled
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // ------------------------------------------------------------------
    // WebViewClient
    // ------------------------------------------------------------------

    private class AppWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            if (!request.isForMainFrame()) {
                return false; // never interfere with iframes
            }
            Uri uri = request.getUrl();
            String scheme = uri.getScheme();
            if (scheme == null) {
                return false;
            }
            scheme = scheme.toLowerCase();
            if (scheme.equals("https")) {
                if (isAppUri(uri)) {
                    return false;
                }
                openExternal(uri);
                return true;
            }
            if (scheme.equals("http")) {
                openExternal(uri);
                return true;
            }
            if (scheme.equals("mailto") || scheme.equals("tel") || scheme.equals("sms")) {
                openExternal(uri);
                return true;
            }
            if (scheme.equals("about") || scheme.equals("blob") || scheme.equals("data")
                    || scheme.equals("javascript")) {
                return false;
            }
            return true; // block unknown schemes (intent:, file:, ...)
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            loadFailed = false;
            pageLoaded = false;
            if (url != null && url.startsWith("http")) {
                lastUrl = url;
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (loadFailed) {
                return;
            }
            pageLoaded = true;
            try {
                CookieManager.getInstance().flush();
            } catch (Exception e) {
                // ignore
            }
            flushPendingChat();
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request,
                                    WebResourceError error) {
            if (request != null && request.isForMainFrame()) {
                loadFailed = true;
                pageLoaded = false;
                Uri u = request.getUrl();
                if (u != null && u.toString().startsWith("http")) {
                    lastUrl = u.toString();
                }
                showOffline();
            }
        }
    }

    // ------------------------------------------------------------------
    // WebChromeClient
    // ------------------------------------------------------------------

    private class AppChromeClient extends WebChromeClient {

        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    handleWebPermission(request);
                }
            });
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest request) {
            if (pendingWebRequest == request) {
                pendingWebRequest = null;
            }
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(null);
            }
            fileCallback = callback;

            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);

            List<String> types = new ArrayList<String>();
            String[] accept = params.getAcceptTypes();
            if (accept != null) {
                for (String a : accept) {
                    if (a == null) {
                        continue;
                    }
                    // accept may be comma separated, or file extensions like ".png"
                    for (String part : a.split(",")) {
                        String t = part.trim();
                        if (t.length() > 0 && t.indexOf('/') > 0) {
                            types.add(t);
                        }
                    }
                }
            }
            if (types.size() == 1) {
                intent.setType(types.get(0));
            } else {
                intent.setType("*/*");
                if (types.size() > 1) {
                    intent.putExtra(Intent.EXTRA_MIME_TYPES,
                            types.toArray(new String[types.size()]));
                }
            }
            if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }

            try {
                startActivityForResult(Intent.createChooser(intent, null), REQ_FILE);
            } catch (ActivityNotFoundException e) {
                fileCallback = null;
                callback.onReceiveValue(null);
                return false;
            }
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            showCustomView(view, callback);
        }

        @Override
        public void onHideCustomView() {
            hideCustomView();
        }
    }
}
